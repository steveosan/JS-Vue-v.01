
// Vue.component('footer-component' ,{
//         template: `<v-footer app>
//             <v-spacer></v-spacer><v-card-text>{{msg1}}</v-card-text> <v-spacer></v-spacer>
//
//           </v-footer>`,
//         data(){
//             return {
//                 msg1: 'Keep working on this',
//             }
//         }
//     }
// )
// I'm still working on learning how to separate these files...

