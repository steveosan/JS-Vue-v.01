// Vue.component('NavBar', ){

//     props: {

//     },

//     Data() {
//         return{

//         }
//     },


    
// }